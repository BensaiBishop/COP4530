

// Assignment 3
// Created on 14-Feb-21.
// Benjamin Bishop

#ifndef STACK_HPP
#define STACK_HPP
#include "stack.h"
template<class T>
cop4530::Stack<T>::Stack() { //default constructor
    init();
}

template<class T>
cop4530::Stack<T>::~Stack() {//deconstructor
    clear();
    delete head;
}

template<class T>
cop4530::Stack<T>::Stack(const cop4530::Stack<T> & rhs) {//copy constructor
    init();
    *this = rhs;
}

template<class T>
cop4530::Stack<T>::Stack(Stack &&rhs) {
    *this=rhs;
    theSize=rhs.size();
}

template<class T>
cop4530::Stack<T> &cop4530::Stack<T>::operator=(const Stack &rhs) {
    //Stack<T> *s;

    s=rhs.s;
    return *this;

}

template<class T>
cop4530::Stack<T> &cop4530::Stack<T>::operator=(Stack &&rhs) {
    std::swap(head,rhs.head);
    std::swap(theSize,rhs.theSize);
    return *this;
}

template<class T>
bool cop4530::Stack<T>::empty() const {
    return theSize==0;
}

template<class T>
void cop4530::Stack<T>::clear() {
    while (!empty()){
        pop();
    }
}

template<class T>
void cop4530::Stack<T>::push(const T &x) {

    Node *element=new Node();
    element->data=x;
    if (head== nullptr){
        element->next= nullptr;
        head=element;

        head->next=element->next;
        delete element;
        ++(theSize);
    }
    else {
        element->next = head;
        head = element;
        head->next = element->next;
        delete element;
        ++(theSize);
    }

}

template<class T>
void cop4530::Stack<T>::push(T &&x) {

    Node *element=new Node();
    element->data=x;
    if (head== nullptr){
        element->next= nullptr;
        head=element;
        head->next=element->next;
        delete element;
        ++theSize;
    }
    else {
        element->next = head;
        head = element;
        head->next = element->next;
        delete element;
        ++theSize;
    }

}

template<class T>
void cop4530::Stack<T>::pop() {

    Node *temp = NULL;
    if (empty()){
        std::cout<<"empty stack;";
        return;
    }
    else {      //what on earth does this thing not like.
        temp = head;
        head = head->next;
        //free(temp);
        //delete temp;
        --theSize;
    }
}

template<class T>
T& cop4530::Stack<T>::top(){

   return head->data;
}

template<class T>
const T &cop4530::Stack<T>::top() const {

    return head->data;
}

template<class T>
int cop4530::Stack<T>::size() const {
    return theSize;
}

template<class T>
void cop4530::Stack<T>::print(std::ostream &os, char ofc) const {

    for(auto itr = 0;itr<theSize; ++itr)
        os << itr << ofc;
}

template<class T>
void cop4530::Stack<T>::init() {
    theSize=0;
    head = nullptr;
}


#endif //STACK_HPP
