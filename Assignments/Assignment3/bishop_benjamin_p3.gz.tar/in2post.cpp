// Assignment 3
// Created on 14-Feb-21.
// Benjamin Bishop

#include <iostream>
#include <string>
#include <cctype>
#include "stack.hpp"

using namespace std;
using namespace cop4530;

bool isOperator(char a);
string in2post(Stack<char> stack, string infix);
int precedence(char a);
int postEval(Stack<char> stack, string postfix);

int main(){
    string infix, postfix;
    do {
        infix.clear();
        postfix.clear();

        cout<<"Enter an Infix expression or 'quit' \n";
        cin>>infix;
        Stack<char> st;
        cout<<"Infix Expression: "<<infix<<endl;
        postfix = in2post(st,infix);
        cout<<endl<<"Postfix Expression: "<<postfix<<endl;
        //postfix = postEval(st, postfix);
        //cout<<endl<<"Postfix Eval: "<<postfix<<endl;
    } while (infix != "quit");
    return 0;
}//end of main

string in2post(Stack<char> stack, string infix){
    string postfix2;
    postfix2.clear();
    for (int i = 0; i < infix.length(); ++i)
    {
        if ((infix[i]>='a'&& infix[i]<='z')||(infix[i]>='A'&&infix[i]<='Z')||(isalnum(infix[i])))
        {
            postfix2+=infix[i];
        }
        else if (infix[i]=='(')
        {
            stack.push(infix[i]);
        }
        else if (infix[i]==')')
        {
            while ((stack.top()!='(') && (!stack.empty()))
            {
                char temp=stack.top();
                postfix2+=temp;
                stack.pop();
            }
            if (stack.top()=='(')
            {
                stack.pop();
            }
        }
        else if (isOperator(infix[i]))
        {
            if (stack.empty())
            {
                stack.push(infix[i]);
            }
            else
                {
                if (precedence(infix[i])>precedence(stack.top()))
                {
                    stack.push(infix[i]);
                }
                else if ((precedence(infix[i])==precedence(stack.top()))&&(infix[i]=='^'))
                {
                    stack.push(infix[i]);
                }
                else{
                    while ((!stack.empty())&&(precedence(infix[i])<=precedence(stack.top())))
                    {
                        postfix2+=stack.top();
                        stack.pop();
                    }
                    stack.push(infix[i]);
                }
            }
        }
    }
    while (!stack.empty())
    {
        postfix2+=stack.top();
        stack.pop();
    }
    return postfix2;
}//end of in2post


bool isOperator(char a){
    if (a =='+'||a =='-'||a =='*'||a =='/'||a =='^') {
        return true;
    }
    else
        return false;
}//end of isOperator

int precedence(char a){
    if (a=='^')
        return 3;
    else if (a=='*'||a=='/')
        return 2;
    else if (a=='+'||a=='-')
        return 1;
    else
        return -1;
}//end of precedence